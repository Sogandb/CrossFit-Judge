# CrossFit Judge 🏋️

AI-powered CrossFit competition judge using MediaPipe Pose and OpenCV. Automatically detects movements, counts valid reps, and scores athletes according to CrossFit Games standards.

## Features

- **6 movements**: Squat, Push-up, Burpee, Thruster, Pull-up, Kettlebell Swing
- **5 workout formats**: AMRAP, For Time, Tabata, EMOM, Max Reps
- **Custom workouts**: Define your own movements, format, and time cap
- **CrossFit Games standards**: Each movement validated against official rules
- **Annotated video**: Skeleton overlay with live counter and per-rep verdicts
- **Rep timeline**: Visual chart of every rep attempt
- **Persian no-rep reasons**: Clear feedback for judges (configurable)
- **Chunked upload**: Handles large videos (5/10/15+ minutes)
- **Disk-persistent jobs**: Survives server restarts

## Requirements

- **Python 3.10+** (tested with 3.12)
- **Node.js 18+** with **bun** (or npm)
- **ffmpeg** (for video transcoding to H.264)
- **4GB+ RAM** (MediaPipe is memory-intensive)

## Quick Start

### 1. Python Backend Setup

```bash
cd mini-services/crossfit-judge
chmod +x setup.sh
./setup.sh
```

This will:
- Install Python dependencies (mediapipe, opencv, fastapi, etc.)
- Download the MediaPipe pose model
- Create data directories

### 2. Start the Python Server

```bash
cd mini-services/crossfit-judge
python3 main.py
```

The server runs on **http://localhost:8001**.

### 3. Start the Next.js Frontend

In the project root (separate terminal):

```bash
bun run dev
```

Or with npm:
```bash
npm run dev
```

The frontend runs on **http://localhost:3000**.

### 4. Open the App

Go to **http://localhost:3000** in your browser.

## How to Use

1. **Select a workout** from the Preset list, or build a Custom workout
2. **Upload your video** (MP4, MOV, or AVI — 45° camera angle recommended)
3. **Wait for analysis** — the engine detects poses and counts reps
4. **Review results** — score, stats, annotated video, rep-by-rep breakdown

## Workout Formats (CrossFit Games Standards)

| Format | Scoring | Example |
|--------|---------|---------|
| **AMRAP** | Total valid reps in time cap | "47 reps" |
| **For Time** | Time to complete (or DNF + reps done) | "8:32" or "47 reps (DNF)" |
| **Tabata** | Total reps across 8 rounds (20s work / 10s rest) | "89 reps" |
| **EMOM** | Total reps completed | "72 reps" |
| **Max Reps** | Maximum valid reps in time cap | "53 reps" |

## Movement Standards

### Squat
- **Bottom**: Hip crease below knee (knee angle ≤ 95°)
- **Top**: Full hip and knee extension (knee angle ≥ 165°)

### Push-up
- **Bottom**: Chest touches ground
- **Top**: Full arm lockout (elbow angle ≥ 155°)

### Burpee
- **Bottom**: Chest and thighs on ground (descent ratio ≥ 35%)
- **Top**: Jump with feet off ground AND hands overhead

### Thruster
- **Bottom**: Deep squat (knee angle ≤ 95°)
- **Top**: Full knee extension + overhead lockout (elbow ≥ 150°)

### Pull-up
- **Top**: Chin above bar
- **Bottom**: Full extension / dead hang (elbow angle ≥ 150°)

### Kettlebell Swing
- **Bottom**: Hip hinge (hip angle ≤ 95°)
- **Top**: Bell reaches target height + full hip extension (≥ 150°)

## Camera Setup

- **Angle**: 45° from the athlete (standard for online competitions)
- **Distance**: Athlete fully visible in frame
- **Lighting**: Good lighting for pose detection
- **Framerate**: 30fps+ recommended for fast movements

## Project Structure

```
crossfit-judge/
├── mini-services/crossfit-judge/    # Python AI engine
│   ├── main.py                      # FastAPI server (port 8001)
│   ├── worker.py                    # Analysis subprocess
│   ├── setup.sh                     # First-time setup
│   ├── requirements.txt             # Python dependencies
│   ├── config/
│   │   ├── settings.py              # Thresholds and config
│   │   └── workouts.py              # Workout definitions
│   ├── core/
│   │   ├── analyzer.py              # Main analysis orchestrator
│   │   ├── pose_detector.py         # MediaPipe wrapper
│   │   ├── video_processor.py       # OpenCV + H.264 transcoding
│   │   ├── timer.py                 # Workout timer
│   │   └── sequence.py              # Multi-movement sequencing
│   ├── movements/                   # Movement detectors
│   │   ├── base_movement.py         # State machine base class
│   │   ├── squat.py
│   │   ├── pushup.py
│   │   ├── burpee.py
│   │   ├── thruster.py
│   │   ├── pullup.py
│   │   └── kettlebell_swing.py
│   ├── judging/
│   │   └── scorer.py                # CrossFit Games scoring
│   ├── reporting/
│   │   ├── video_annotator.py       # Skeleton overlay
│   │   ├── timeline.py              # Rep timeline chart
│   │   └── report_generator.py      # JSON report
│   └── tests/
│       └── test_synthetic.py        # Self-test
├── src/                             # Next.js frontend
│   ├── app/
│   │   ├── page.tsx                 # Main UI
│   │   └── api/judge/[...path]/     # Proxy to Python
│   ├── components/crossfit/         # UI components
│   └── lib/
│       ├── crossfit-api.ts          # API client
│       └── python-server.ts         # Python process manager
└── package.json                     # Next.js dependencies
```

## Troubleshooting

### "mediapipe module not found"
Run `./setup.sh` again, or: `pip3 install mediapipe`

### "libGLESv2.so.2 not found" (Linux)
Install graphics libraries: `sudo apt install libgles2 libegl1`
Or the server auto-creates symlinks from Chrome if available.

### Video won't play in browser
The server transcodes to H.264 via ffmpeg. Make sure ffmpeg is installed:
- Ubuntu: `sudo apt install ffmpeg`
- macOS: `brew install ffmpeg`
- Windows: Download from ffmpeg.org

### Upload fails
- Check both servers are running (Python on 8001, Next.js on 3000)
- Try a shorter video (under 60 seconds)
- Re-encode to MP4 H.264 if needed

## License

MIT — Free to use for CrossFit competitions and training.
